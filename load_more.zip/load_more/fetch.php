<?php
$conn= mysqli_connect('localhost','root','','load_more_db');
 //mysql_select_db('load_more_db');

 $no = $_POST['getresult'];
 $select = mysqli_query($conn,"select * from load_more_tbl limit $no,2");
 while($row = mysqli_fetch_assoc($select))
 {
  echo "<p class='result'>".$row['name']."</p>";
 }
?>