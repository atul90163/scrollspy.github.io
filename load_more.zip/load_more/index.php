<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 4 Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script type="text/javascript">
$(document).ready(function(){
 $("#load").click(function(){
  loadmore();
 });
});

function loadmore()
{
 var val = document.getElementById("result_no").value;
 $.ajax({
 type: 'post',
 url: 'fetch.php',
 data: {
  getresult:val
 },
 success: function (response) {
  var content = document.getElementById("result_para");
  content.innerHTML = content.innerHTML+response;

  // We increase the value by 2 because we limit the results by 2
  document.getElementById("result_no").value = Number(val)+2;
 }
 });
}
</script>
<style type="text/css">body
{
 background-color:#E6E6E6;
 font-family:helvetica;
}
#heading
{
 margin-top:150px;
 width:600px;
 font-size:27px;
 color:#2E2EFE;
}
.result
{
 text-align:left;
 background-color:grey;
 width:400px;
 padding:10px;
 box-sizing:border-box;
 color:#F2F2F2;
 border-radius:3px;
 border:1px solid #424242;
 font-style:italic;
}
#load
{
 width:400px;
 height:40px;
 color:brown;
 background-color:brown;
 border-radius:3px;
 color:white;
 border:none;
 font-size:17px;
}</style>

</head>
<body>

<div class="container">
  
  
  <center>
<p>load more code</p>
 <div id="content">
  <div id="result_para">
  <?php
  $conn=mysqli_connect('localhost','root','','load_more_db');
 // mysqli_select_db('load_more_db');
  
  $select = mysqli_query($conn,"select * from load_more_tbl limit 0,2");
  while($row = mysqli_fetch_assoc($select))
  {
   echo "<p class='result'>".$row['name']."</p>";
  }
  ?>
  
  
  <input type="hidden" id="result_no" value="2">
  
  </div>
 </div>
 <input type="button" id="load" value="Load More Results">
</center>
</div>

</body>
</html>