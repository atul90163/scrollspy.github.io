<?php include "header.php"; ?>
<div class="page-title-area bg-2">
<div class="container">
<div class="page-title-content">
<h2>Contact us</h2>
<ul>
<li>
<a href="index.php">
Home
</a>
</li>
<li class="active">Contact us</li>
</ul>
</div>
</div>
</div>


<div class="map-area pt-100">
<div class="container">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d42902.5492203417!2d-122.24081983396803!3d47.77351040839244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54900e5a62e5fd6b%3A0x72449f1539850b0!2sBothell%2C%20WA%2C%20USA!5e0!3m2!1sen!2sbd!4v1597638866793!5m2!1sen!2sbd"></iframe>
</div>
</div>


<section class="main-contact-area ptb-100">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-8">
<div class="contact-wrap">
<div class="contact-form">
<div class="contact-title">
<h2>Drop us message for any query</h2>
</div>
<form id="contactForm">
<div class="row">
<div class="col-lg-6 col-sm-6">
<div class="form-group">
<label>Name</label>
<input type="text" name="name" id="name" class="form-control" required data-error="Please enter your name">
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-lg-6 col-sm-6">
<div class="form-group">
<label>Email Address</label>
<input type="email" name="email" id="email" class="form-control" required data-error="Please enter your email">
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-12">
<div class="form-group">
<label>Subject</label>
<input type="text" name="msg_subject" id="msg_subject" class="form-control" required data-error="Please enter your subject">
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-12">
<div class="form-group">
<label>Message</label>
<textarea name="message" class="form-control" id="message" cols="30" rows="10" required data-error="Write your message"></textarea>
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-lg-12 col-md-12">
<button type="submit" class="default-btn btn-two" disabled="disabled">
Send message
</button>
<div id="msgSubmit" class="h3 text-center hidden"></div>
<div class="clearfix"></div>
</div>
</div>
</form>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="contact-info">
<h3>Our contact details</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
<ul class="address">
<li class="location">
<i class="bx bxs-location-plus"></i>
<span>Address</span>

Facatory : I-185, Sector 3, Bawana, Delhi
</li>
<li>
<i class="bx bxs-phone-call"></i>
<span>Phone</span>
<a href="tel:+91- 8178477696">+91- 8178477696</a>
<!-- <a href="tel:+1-(514)-312-6688">+1 (514) 312-6688</a>
 --></li>
<li>
<i class="bx bxs-envelope"></i>
<span>Email</span>
<a href="#"><span class="__cf_email__" data-cfemail="39515c555556794149584b4d175a5654">info@sbgparts.com</span></a>
</li>
</ul>
<div class="sidebar-follow-us">
<h3>Follow us:</h3>
<ul class="social-wrap">
<li>
<a href="#" target="_blank">
<i class="bx bxl-twitter"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-instagram"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-facebook"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-youtube"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</section>



<?php include "footer.php"; ?>