<?php include "header.php"; ?>




<div class="page-title-area bg-20">
<div class="container">
<div class="page-title-content">
<h2>Our Plants</h2>
<ul>
<li>
<a href="index.html">
Home
</a>
</li>
<li class="active">Plants</li>
</ul>
</div>
</div>
</div>


<div class="projects-area gallery-popup ptb-100">
<div class="container">
<div class="shorting-menu">
<button class="filter" data-filter="all">
Show all
</button>
<button class="filter" data-filter=".a">
Gaskets
</button>
 <button class="filter" data-filter=".b">
footrest
</button>
</div>
<div class="shorting">
<div class="row">
<div class="col-lg-4 col-sm-6 a d f mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200.jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 b e mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 e a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 b c d e mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 a e f mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 b c e mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 b c d e mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0 a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/1_w1200 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1_w1200 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-12 text-center">
<!-- <a href="#" class="default-btn disabled">
Load more
</a>
 --></div>
</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>