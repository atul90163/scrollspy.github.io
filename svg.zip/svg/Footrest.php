<?php include "header.php"; ?>


<div class="page-title-area bg-8">
<div class="container">
<div class="page-title-content">
<h2>Two Wheelers Footrest</h2>
<ul>
<li>
<a href="index.html">
Home
</a>
</li>
<li class="active">Footrest</li>
</ul>
</div>
</div>
</div>


<section class="services-area services-area-style-three ptb-100">
<div class="container-fluid">
<div class="section-title">
<span>Our Services</span>
<p>We are renowned supplier of wide range of two wheeler spare parts. The main parts which we are suppling for the two wheelers are motorcycle brake rod, motorcycle rear brake rod, two wheeler brake rod, bullet brake rod, enticer brake road and others. Our wide range of two wheeler spare parts has made us a one stop shop for all two wheeler replacement needs.
</p>
</div>
</div>
<div class="projects-area gallery-popup ptb-100" style="padding-top:0;">
<div class="container">
<div class="shorting">
<div class="row">
<div class="col-lg-4 col-sm-6 a d f mix">
<div class="gallery">
<img src="assets/img/gallery-img/1 (1).jpg" alt="Image">
<a href="assets/img/gallery-img/1 (1).jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 b e mix">
<div class="gallery">
<img src="assets/img/gallery-img/2.jpg" alt="Image">
<a href="assets/img/gallery-img/2.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 e a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/3.jpg" alt="Image">
<a href="assets/img/gallery-img/3.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 b c d e mix">
<div class="gallery">
<img src="assets/img/gallery-img/4.jpg" alt="Image">
<a href="assets/img/gallery-img/4.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 a e f mix">
<div class="gallery">
<img src="assets/img/gallery-img/5.jpg" alt="Image">
<a href="assets/img/gallery-img/5.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 b c e mix">
<div class="gallery">
<img src="assets/img/gallery-img/6.jpg" alt="Image">
<a href="assets/img/gallery-img/6.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/7.jpg" alt="Image">
<a href="assets/img/gallery-img/7.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 b c d e mix">
<div class="gallery">
<img src="assets/img/gallery-img/8.jpg" alt="Image">
<a href="assets/img/gallery-img/8.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0 a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/9.jpg" alt="Image">
<a href="assets/img/gallery-img/9.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0 a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/10.jpg" alt="Image">
<a href="assets/img/gallery-img/10.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0 a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/11.jpg" alt="Image">
<a href="assets/img/gallery-img/11.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div><div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0 a f mix">
<div class="gallery">
<img src="assets/img/gallery-img/12.jpg" alt="Image">
<a href="assets/img/gallery-img/12.jpg" class="view-gallery">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
<div class="col-12 text-center">
<!-- <a href="#" class="default-btn disabled">
Load more
</a>
 --></div>
</div>
</div>
</div>
</div>



</section>


<?php include "footer.php"; ?>