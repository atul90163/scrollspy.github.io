<!doctype html>
<html lang="zxx">

<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

<link rel="stylesheet" href="assets/css/owl.carousel.min.css">

<link rel="stylesheet" href="assets/css/magnific-popup.css">

<link rel="stylesheet" href="assets/css/animate.css">

<link rel="stylesheet" href="assets/css/boxicons.min.css">

<link rel="stylesheet" href="assets/css/flaticon.css">

<link rel="stylesheet" href="assets/css/meanmenu.css">

<link rel="stylesheet" href="assets/css/before-after.min.css">

<link rel="stylesheet" href="assets/css/nice-select.css">

<link rel="stylesheet" href="assets/css/odometer.css">

<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet" href="assets/css/responsive.css">

<link rel="icon" type="image/png" href="assets/img/favicon.png">

<title>SBG parts</title>

</head>
<body>

<div class="loader-wrapper">
<div class="loader">
<img src="assets/img/lode.gif" alt="Image">
</div>
</div>


<header class="header-area" id="header">

<div class="top-header">
<div class="container-fluid">
<div class="row align-items-center">
<div class="col-lg-8 col-sm-8 pl-0">
<ul class="header-left-content">
<li>
<i class="flaticon-clock-1"></i>
Working Hours: Mon - Sat 11:00 am - 9:00 pm
</li>
<li>
<i class="flaticon-call"></i>
Contact:
<a href="tel:+91- 8178477696">+91- 8178477696</a>
</li>
</ul>
</div>
<div class="col-lg-4 col-sm-4 pr-0">
<ul class="header-right-content">
<li>
<a href="#" target="_blank">
<i class="bx bxl-facebook"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-instagram"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-twitter"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-linkedin-square"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>


<div class="navbar-area">
<div class="mobile-nav">
<div class="container-fluid">
<a href="index.php" class="logo">
<img src="assets/img/cropped-SBG_LOGO-3.png" alt="Logo" style="max-height: 40px;" class="img-responsive " >
</a>
</div>
</div>
<div class="main-nav">
<div class="container-fluid">
<nav class="navbar navbar-expand-md">
<a class="navbar-brand" href="index.php">
<img src="assets/img/cropped-SBG_LOGO-3.png" alt="Logo" class="img-responsive" style="height:70px; " >
</a>
<div class="collapse navbar-collapse mean-menu">
<ul class="navbar-nav m-auto">
<li class="nav-item">
<a href="index.php" class="nav-link active">
Home</a>
</li>
 <li class="nav-item">
<a href="about.php" class="nav-link">About</a>
</li>

 <li class="nav-item">
<a href="plants.php" class="nav-link">plants</a>
</li>



<li class="nav-item">
<a href="#" class="nav-link">
Products
<i class="bx bx-chevron-down"></i>
</a></li>
<li class="nav-item">
<a href="contact-us.php" class="nav-link">Contact Us</a>
</li>
</ul></div>
</nav>
</div>
</div>
</div>

</header>

