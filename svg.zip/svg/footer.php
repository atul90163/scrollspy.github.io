

<footer class="footer-area pt-100">
<div class="container">
<div class="row " style="">
<div class="  col-lg-4 col-md-6">
<div class="single-footer-widget">
<a href="index.php" class="footer-logo">
<img src="assets/img/white-logo.png" alt="Image" style="width: 202px; height:70px;">
</a>
<ul class="address">
<li class="location">
<i class="flaticon-pin"></i>
Facatory : I-185, Sector 3, Bawana, Delhi
</li>
<li>
<i class="flaticon-envelope"></i>
<a href="#">info@sbgparts.com</span></a>
</li>
<li>
<i class="flaticon-telephone"></i>
<a href="tel:+91- 8178477696"> +91- 8178477696</a>
</li>
 </ul>
</div>
</div>
<div class="col-lg-4 col-md-6">
<div class="single-footer-widget">
<h3>Quick Links </h3>
<ul class="import-link">
<li>
<a href="index.php">Home</a>
</li>
<li>
<a href="Footrest.php">Two Wheelers Footrest</a>
</li>
<li>
<a href="plants.php">Plants</a>
</li>
<li>
<a href="about.php">About</a>
</li>
<li>
<a href="gaskets.php">Gaskets</a>
</li>
<li>
<a href="contact-us.php">Contact Us</a>
</li>
</ul>
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="single-footer-widget">
<h3>Working hours</h3>
<ul class="time">
<li>
Monday:
<span>11:00 am - 9:00 pm</span>
</li>
<li>
Tuesday:
<span>Closed</span>
</li>
<li>
Wednesday:
<span>11:00 am - 9:00 pm</span>
</li>
<li>
Thursday:
<span>11:00 am - 9:00 pm</span>
</li>
<li>
Friday:
<span>11:00 am - 9:00 pm</span>
</li>
<li>
Saturday:
<span>11:00 am - 9:00 pm</span>
</li>
<li>
Sunday:
<span>11:00 am - 9:00 pm</span>
</li>
</ul>
</div>
</div>
</div>
</div>


<div class="container">
<div class="copy-right-content">
<div class="row align-items-center">
<div class="col-lg-6">
<p>© SBG - Made with LOVE in India by : Designed By <a href="https://www.designpitara.com/" target="blank">Design Pitara</a></p>
</div>
<div class="col-lg-6">
<ul class="footer-menu">
<li>
<a href="#">
Privacy policy
</a>
</li>
<li> 
<a href="#">
Terms and conditions
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</footer>


<div class="go-top">
<i class="bx bx-chevrons-up"></i>
<i class="bx bx-chevrons-up"></i>
</div>


<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery-3.5.1.slim.min.js"></script>

<script src="assets/js/popper.min.js"></script>

<script src="assets/js/bootstrap.min.js"></script>

<script src="assets/js/jquery.meanmenu.js"></script>

<script src="assets/js/wow.min.js"></script>

<script src="assets/js/owl.carousel.js"></script>

<script src="assets/js/jquery.magnific-popup.min.js"></script>

<script src="assets/js/before-after.min.js"></script>

<script src="assets/js/jquery.nice-select.min.js"></script>

<script src="assets/js/parallax.min.js"></script>

<script src="assets/js/jquery.mixitup.min.js"></script>

<script src="assets/js/jquery.appear.js"></script>

<script src="assets/js/odometer.min.js"></script>

<script src="assets/js/form-validator.min.js"></script>

<script src="assets/js/contact-form-script.js"></script>

<script src="assets/js/jquery.ajaxchimp.min.js"></script>

<script src="assets/js/custom.js"></script>
</body>

</html>