<?php include "header.php"; ?>


<section class="banner-area banner-area-three">
<div class="banner-slider owl-carousel owl-theme">
<div class="banner-slider-item bg-4">
<div class="d-table">
<div class="d-table-cell">
<div class="container-fluid">
<div class="banner-content two">
<h1>Your trusted auto repair shop</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt agna aliqua quis ipsum suspendisse.</p>
<div class="banner-btn">
<a class="default-btn" href="appointment.html">
Appointment now
</a>
 </div>
</div>
</div>
</div>
</div>
</div>
<div class="banner-slider-item bg-5">
<div class="d-table">
<div class="d-table-cell">
<div class="container-fluid">
<div class="banner-content two">
<h1>Gaskets</h1>
<p>We have vast range of two wheeler gasket kits. Our product range includes two wheeler gasket sets, head gasket, gasket packing kit and others.</p>
<div class="banner-btn">
<a class="default-btn" href="#">
Read More
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="banner-slider-item bg-5">
<div class="d-table">
<div class="d-table-cell">
<div class="container-fluid">
<div class="banner-content two">
<h1>Two Wheelers footrest</h1>
<p>We are renowned supplier of wide range of two wheeler spare parts.The main parts which we are suppling for the two wheelers are motorcycle brake rod, motorcycle rear brake rod, two wheeler brake rod,</p>
<div class="banner-btn">
<a class="default-btn" href="appointment.html">Read More
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="about-area ptb-100">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-6">
<div class="about-img">
<div class="about-img-1">
<img src="assets/img/about-img/about-2.jpg" alt="Image">
</div>
<div class="about-img-2">
<img src="assets/img/about-img/about-1.jpg" alt="Image">
</div>
<div class="experience">
<h2>25</h2>
<p>Years of experience</p>
</div>
</div>
</div>
<div class="col-lg-6">
<div class="about-content">
<!-- <span>Main Principles</span> -->
<h2 style="">Certified manufacturing unit </h2>
<p>We are Government certified manufacturing unit and
have highly trained professionals to check product quality
at every stage before sending it to market. </p>
<span >We are here to help with your transportation too.</span>
<div class="about-btn">
<!-- <a href="services-style-one.html" class="default-btn">
</a>
 --></div>
</div>
</div>
</div>
</div>
</section>


<!-- <section class="our-skills-area pb-100">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-6">
<div class="skills-content">
<span>Our Skills</span>
<h2>Why we’re best for auto repairing</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendis ultrices gravida. maecenas accumsan lacus vel facilisis consectetur adipiscing.</p>
</div>
<div class="all-skill-bar">
<div class="skill-bar" data-percentage="80%">
<h4 class="progress-title-holder">
<span class="progress-title">Valuable cost</span>
<span class="progress-number-wrapper">
<span class="progress-number-mark">
<span class="percent"></span>
<span class="down-arrow"></span>
</span>
</span>
</h4>
<div class="progress-content-outter">
<div class="progress-content"></div>
</div>
</div>
<div class="skill-bar" data-percentage="95%">
<h4 class="progress-title-holder clearfix">
<span class="progress-title">High quality services</span>
<span class="progress-number-wrapper">
<span class="progress-number-mark">
<span class="percent"></span>
<span class="down-arrow"></span>
</span>
</span>
</h4>
<div class="progress-content-outter">
<div class="progress-content"></div>
</div>
</div>
<div class="skill-bar mb-0" data-percentage="90%">
<h4 class="progress-title-holder clearfix">
<span class="progress-title">Support quality</span>
<span class="progress-number-wrapper">
<span class="progress-number-mark">
<span class="percent"></span>
<span class="down-arrow"></span>
</span>
</span>
</h4>
<div class="progress-content-outter">
<div class="progress-content"></div>
</div>
</div>
</div>
</div>
<div class="col-lg-6">
<div class="skill-img">
<img src="assets/img/skill-img.png" alt="Image">
</div>
</div>
</div>
</div>
</section>

 --><!-- 
<div class="partner-area ptb-100">
<div class="container">
<div class="partner-slider owl-theme owl-carousel">
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-1.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-2.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-3.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-4.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-5.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-6.png" alt="Image">
</a>
</div>
</div>
</div>
</div>


<div class="gallery-area">
<div class="gallery-slider owl-theme owl-carousel">
<div class="gallery-single-item">
<img src="assets/img/gallery-img/gallery-1.jpg" alt="Image">
<a href="services-details.html">
Brakes repair services
<i class="flaticon-right-arrow"></i>
</a>
</div>
<div class="gallery-single-item">
<img src="assets/img/gallery-img/gallery-2.jpg" alt="Image">
<a href="services-details.html">
Brakes repair services
<i class="flaticon-right-arrow"></i>
</a>
</div>
<div class="gallery-single-item">
<img src="assets/img/gallery-img/gallery-3.jpg" alt="Image">
<a href="services-details.html">
Brakes repair services
<i class="flaticon-right-arrow"></i>
</a>
</div>
<div class="gallery-single-item">
<img src="assets/img/gallery-img/gallery-4.jpg" alt="Image">
<a href="services-details.html">
Brakes repair services
<i class="flaticon-right-arrow"></i>
</a>
</div>
</div>
</div>

 -->
<section class="services-area pt-100 pb-70">
<div class="container">
<div class="section-title">
<!-- <span>Our Services</span>
 --><h2>Our Products</h2>
</div>
<div class="row">
<div class="col-lg-6 col-sm-6">
<div class="single-services-box">
<div class="icon">
<img src="assets/img/services-main-shape.png" alt="Image">
<i class="flaticon-diagnostic"></i>
<div class="services-hover-shape">
<img src="assets/img/services-hover-shape.png" alt="Image">
</div>
</div>
<h3>Two Wheelers footrest</h3>
<p>We are renowned supplier of wide range of two wheeler spare parts.The main parts which we are suppling for the two wheelers are motorcycle brake rod, motorcycle rear brake rod, two wheeler brake rod,
</p>
<a href="services-details.html" class="read-more">
Read more
</a>
</div>
</div>
<div class="col-lg-6 col-sm-6">
<div class="single-services-box">
<div class="icon">
<img src="assets/img/gasket3.jpg" alt="Image" style="height:148px; width:110px;">
<!-- <i class="flaticon-wheel-alignment"></i> -->
<div class="services-hover-shape">
<img src="assets/img/gasket3.jpg" alt="Image" style="height:148px; width:110px;">
</div>
</div>
<h3>Gaskets</h3>
<p>We have vast range of two wheeler gasket kits. Our product range includes two wheeler gasket sets, head gasket, gasket packing kit and others.</p>
<a href="services-details.html" class="read-more">
Read more
</a>
</div>
</div>
<!-- <div class="col-lg-4 col-sm-6">
<div class="single-services-box">
<div class="icon">
<img src="assets/img/services-main-shape.png" alt="Image">
<i class="flaticon-brakes"></i>
<div class="services-hover-shape">
<img src="assets/img/services-hover-shape.png" alt="Image">
</div>
</div>
<h3>Brake repairing</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt dolore magna aliqua.</p>
<a href="services-details.html" class="read-more">
Read more
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="single-services-box">
<div class="icon">
<img src="assets/img/services-main-shape.png" alt="Image">
<i class="flaticon-painting"></i>
<div class="services-hover-shape">
<img src="assets/img/services-hover-shape.png" alt="Image">
</div>
</div>
<h3>Car painting</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt dolore magna aliqua.</p>
<a href="services-details.html" class="read-more">
Read more
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="single-services-box">
<div class="icon">
<img src="assets/img/services-main-shape.png" alt="Image">
<i class="flaticon-car-service"></i>
<div class="services-hover-shape">
<img src="assets/img/services-hover-shape.png" alt="Image">
</div>
</div>
<h3>Car washes</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt dolore magna aliqua.</p>
<a href="services-details.html" class="read-more">
Read more
</a>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="single-services-box">
<div class="icon">
<img src="assets/img/services-main-shape.png" alt="Image">
<i class="flaticon-car-service-1"></i>
<div class="services-hover-shape">
<img src="assets/img/services-hover-shape.png" alt="Image">
</div>
</div>
<h3>Oil change & lube</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt dolore magna aliqua.</p>
<a href="services-details.html" class="read-more">
Read more
</a>
</div>
</div>
</div>
 --></div>
</section>
<section class="appointment-area bg-color ptb-100">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-6">
<div class="appointment-content">
<h2>About Us</h2>
<p>Dahiya Auto Spares is a one stop supplier for all two wheeler spare parts. The company was formulated in the year 2014. The supplier company is situated in Delhi. The demand of two wheeler spare parts is rising at a firm pace. We provide various parts for different models of Bullet, CBZ, Activa, Honda, Karizma and many others.</p>
</div>
<!-- <form class="appointment-form">
<div class="row">
<div class="col-lg-6 col-sm-6">
<div class="form-group">
<input type="text" class="form-control" id="First-Name" placeholder="Name">
</div>
</div>
<div class="col-lg-6 col-sm-6">
<div class="form-group">
<input type="email" class="form-control" id="Email" placeholder="Email">
</div>
</div>
<div class="col-lg-6 col-sm-6">
<div class="form-group">
<input type="text" class="form-control" id="Number" placeholder="Phone number">
</div>
</div>
<div class="col-lg-6 col-sm-6">
<div class="form-group">
<select>
<option value="">Select your services</option>
<option value="">Car repair</option>
<option value="">Car washes</option>
<option value="">Car style</option>
<option value="">Car working</option>
</select>
</div>
</div>
<div class="col-lg-12">
<div class="form-group">
<textarea name="message" class="form-control" id="Message" cols="30" rows="5" placeholder="Message"></textarea>
</div>
</div>
</div>
<button type="submit" class="default-btn">
Send message
</button>
</form>
 --></div>
<div class="col-lg-6">
<div class="appointment-img">
<img src="assets/img/appointment-img.png" alt="Image">
<div class="appointment-shape">
<img src="assets/img/appointment-shape.png" alt="Image">
</div>
<div class="video-content">
<a href="https://www.youtube.com/watch?v=Jiiv6htH_dc" class="video-btn popup-youtube">
<i class="flaticon-play"></i>
</a>
</div>
</div>
</div>
</div>
</div>
</section>



<section class="counter-area pb-70 pt-3">
<div class="container">
<div class="row">
<div class="col-lg-4 col-sm-6">
<div class="single-counter">
<!-- <i class="flaticon-plumber"></i>
 --><i class="flaticon-customers"></i>

<h2>
<span class="odometer" data-count="20">00</span>%
<!-- <span class="target">%</span>
 -->
</h2>
<h3>EXPERIENCED TECHNICIANS</h3>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="single-counter">
<i class="flaticon-customers"></i>
<h2>
<span class="odometer" data-count="100">00</span>
<span class="target">+</span>
</h2>
<h3>TRANSPARENCY MATTERS</h3>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="single-counter">
<i class="flaticon-goal-1"></i>
<h2>
<span class="odometer" data-count="2">00</span>
</h2>
<h3>MANUFACTURING UNITS</h3>
</div>
</div>

</div>
</div>
</section>


<section>
	




</section>
<!-- 

<section class="team-area pt-100 pb-70">
<div class="container">
<div class="section-title">
<span>Expert people</span>
<h2>Global leadership team</h2>
</div>
<div class="row">
<div class="col-lg-3 col-sm-6">
<div class="single-team-member">
<div class="team-img">
<img src="assets/img/team-img/team-1.jpg" alt="Image">
<ul>
<li>
<a href="#" target="_blank">
<i class="bx bxl-facebook"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-instagram"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-twitter"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-linkedin-square"></i>
</a>
</li>
</ul>
</div>
<div class="team-content">
<h3>Jerome Luel</h3>
<p>Managing director</p>
</div>
</div>
</div>
<div class="col-lg-3 col-sm-6">
<div class="single-team-member">
<div class="team-img">
<img src="assets/img/team-img/team-2.jpg" alt="Image">
<ul>
<li>
<a href="#" target="_blank">
<i class="bx bxl-facebook"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-instagram"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-twitter"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-linkedin-square"></i>
</a>
</li>
</ul>
</div>
<div class="team-content">
<h3>Andrew Learoyd</h3>
<p>Chief executive</p>
</div>
</div>
</div>
<div class="col-lg-3 col-sm-6">
<div class="single-team-member">
<div class="team-img">
<img src="assets/img/team-img/team-3.jpg" alt="Image">
<ul>
<li>
<a href="#" target="_blank">
<i class="bx bxl-facebook"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-instagram"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-twitter"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-linkedin-square"></i>
</a>
</li>
</ul>
</div>
<div class="team-content">
<h3>Harry Nelis</h3>
<p>Technology officer</p>
</div>
</div>
</div>
<div class="col-lg-3 col-sm-6">
<div class="single-team-member">
<div class="team-img">
<img src="assets/img/team-img/team-4.jpg" alt="Image">
<ul>
<li>
<a href="#" target="_blank">
<i class="bx bxl-facebook"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-instagram"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-twitter"></i>
</a>
</li>
<li>
<a href="#" target="_blank">
<i class="bx bxl-linkedin-square"></i>
</a>
</li>
</ul>
</div>
<div class="team-content">
<h3>Lucy Vernall</h3>
<p>Chief officer</p>
</div>
</div>
</div>
</div>
</div>
</section>




<section class="blog-area pt-100 pb-70">
<div class="container">
<div class="section-title">
<span>Recent news</span>
<h2>Success story posts</h2>
</div>
<div class="row">
<div class="col-lg-4 col-md-6">
<div class="single-blog-post">
<div class="blog-img">
<a href="blog-details.html">
<img src="assets/img/blog-img/blog-1.jpg" alt="Image">
</a>
<span class="date">August 05, 2020</span>
</div>
<div class="news-content">
<a href="#" class="admin">
<img src="assets/img/blog-img/admin-1.jpg" alt="Image">
Andrew Lawson
</a>
<a href="blog-details.html">
<h3>Top 10 automotive advancements to look forward</h3>
</a>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua consectetur adipiscing elit.</p>
<a href="blog-details.html" class="read-more">
Read more
<span class="flaticon-next"></span>
 </a>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6">
<div class="single-blog-post">
<div class="blog-img">
<a href="blog-details.html">
<img src="assets/img/blog-img/blog-2.jpg" alt="Image">
</a>
<span class="date">August 04, 2020</span>
</div>
<div class="news-content">
<a href="#" class="admin">
<img src="assets/img/blog-img/admin-2.jpg" alt="Image">
Carl Batsonn
</a>
<a href="blog-details.html">
<h3>What should you know before choosing a car repair shop</h3>
</a>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua consectetur adipiscing elit.</p>
<a href="blog-details.html" class="read-more">
Read more
<span class="flaticon-next"></span>
</a>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
<div class="single-blog-post">
<div class="blog-img">
<a href="blog-details.html">
<img src="assets/img/blog-img/blog-3.jpg" alt="Image">
</a>
<span class="date">August 03, 2020</span>
</div>
<div class="news-content">
<a href="#" class="admin">
<img src="assets/img/blog-img/admin-3.jpg" alt="Image">
Lance Miller
</a>
<a href="blog-details.html">
<h3>What is the cost of repairing a scratch on a car?</h3>
</a>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua consectetur adipiscing elit.</p>
<a href="blog-details.html" class="read-more">
Read more
<span class="flaticon-next"></span>
</a>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="subscribe-area">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-3 col-sm-6">
<div class="subscribe-content">
<h3>Stay up to date</h3>
<span>Subscribe to our newsletter</span>
</div>
</div>
<div class="col-lg-6 col-sm-6">
<form class="newsletter-form" data-toggle="validator">
<input type="email" class="form-control" placeholder="Enter email address" name="EMAIL" required autocomplete="off">
<button class="send-btn" type="submit">
<i class="flaticon-send"></i>
</button>
<div id="validator-newsletter" class="form-result"></div>
</form>
</div>
<div class="col-lg-3 col-sm-6 offset-sm-3 offset-lg-0">
<div class="subscribe-img">
<img src="assets/img/subscribe-img.png" alt="Image">
</div>
</div>
</div>
</div>
</section>
 -->

<?php include "footer.php"; ?>