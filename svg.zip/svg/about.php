<?php include "header.php"; ?>





<div class="page-title-area bg-1">
<div class="container">
<div class="page-title-content">
<h2>About</h2>
<ul>
<li>
<a href="index.html">
Home
</a>
</li>
<li class="active">About</li>
</ul>
</div>
</div>
</div>


<section class="about-area about-area-three pt-100 pb-130">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-6">
<div class="about-img-two">
<img src="assets/img/about-img/about-3.png" alt="Image">
<div class="about-3-shape">
<img src="assets/img/about-img/about-3-shape.png" alt="Image">
</div>
<div class="experience-shape">
<img src="assets/img/about-img/experience-shape.png" alt="Image">

<div class="experience-two">
<div class="about-img-content">
<h2>25</h2>
<p>years of experience</p>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-6">
<div class="about-content">
<span>Main Principles</span>
<h2>About Dahiya Auto Spares</h2>
<p>Dahiya Auto Spares is a one stop supplier for all two wheeler spare parts. The company was formulated in the year 2014. The supplier company is situated in Delhi. The demand of two wheeler spare parts is rising at a firm pace. We provide various parts for different models of Bullet, CBZ, Activa, Honda, Karizma and many others.

We are leading sellers of motorcycle brake rod, two wheeler brake rod, motorcycle rear brake rod, bikes front foot rest rod and many others in the two wheeler category. We provide the items in bulk to retailers. We provide good quality products and have set of satisfied clients.

Our commitment with customers has led us to achieve a leading position in our product line.

 </p>

</div>
</div>
</div>
</div>
</section>



<section class="testimonial-area fdfcf8-bg-color ptb-100">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-6 ">
<div class="testimonial-img-three"><!-- 
<img src="assets/img/1.jpg" alt="Image"> -->
<div class="gallery">
<img src="assets/img/1.jpg" alt="Image">
<a href="assets/img/1.jpg" class=" disabled view-gallery ">
<i class='bx bx-show-alt'></i>
</a>
</div>
</div>
</div>
<div class="col-lg-6">
<div class="testimonial">
<div class="testimonial-title">
<h2>TWO WHEELER SPARE PARTS</h2>
<p>We are renowned supplier of wide range of two wheeler spare parts. The main parts which we are suppling for the two wheelers are motorcycle brake rod, motorcycle rear brake rod, two wheeler brake rod, bullet brake rod, enticer brake road and others. Our wide range of two wheeler spare parts has made us a one stop shop for all two wheeler replacement needs.</p>
</div>

</div>
</div>
</div>
</div>
</section>

<section class="testimonial-area fdfcf8-bg-color ptb-100">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-6">
<div class="testimonial-img-three">
<img src="assets/img/gasket5.jpg" alt="Image">
</div>
</div>
<div class="col-lg-6">
<div class="testimonial">
<div class="testimonial-title">
<h2>GASKETS</h2>
<p>We have vast range of two wheeler gasket kits. Our product range includes two wheeler gasket sets, head gasket, gasket packing kit and others. The gaskets offered by us have following feature- <ul><li>1. Crack Resistance</li>

<li>2. Superior Finish</li>

<li>3. Accurate Dimension</li>

<li>4. Longer Life </li>

<li>5. Corrosion Resistance</li></ul></p>
</div>

</div>
</div>
</div>
</div>
</section>


<div class="partner-area partner-area-style-two ptb-100">
<div class="container">
<div class="partner-slider owl-theme owl-carousel">
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-1.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-2.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-3.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-4.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-5.png" alt="Image">
</a>
</div>
<div class="partner-item">
<a href="#">
<img src="assets/img/partner-img/partner-6.png" alt="Image">
</a>
</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>