
<?php
if(isset($_POST['submit'])){

$n=$_POST['name'];
$e=$_POST['email'];
$m=$_POST['mobile'];
$r=$_POST['one_hr'];
$data= $n.' '.$e.' '.$m.' '.$r;
$file="folders/data.txt";
$handle = fopen($file, "a") or die("ERROR: Cannot open the file.");
    

fwrite($handle, $data) or die ("ERROR: Cannot write the file.");
fclose($handle);
// Recipient 
$to = 'johhnyrajput24@gmail.com'; 
 
// Sender 
$from = 'atulkumar90163@gmail.com'; 
$fromName = 'Atul'; 
 
// Email subject 
$subject = 'PHP Email with Attachment by Atul';  
 
// Attachment file 
//$file = "files/codexworld.pdf"; 
 
// Email body content 
$htmlContent = ' 
    <h3>PHP Email with Attachment by CodexWorld</h3> 
    <p>This email is sent from the PHP script with attachment.</p> 
'; 
 
// Header for sender info 
$headers = "From: $fromName"." <".$from.">"; 
 
// Boundary  
$semi_rand = md5(time());  
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";  
 
// Headers for attachment  
$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
 
// Multipart boundary  
$message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" . 
"Content-Transfer-Encoding: 7bit\n\n" . $htmlContent . "\n\n";  
 
// Preparing attachment 
if(!empty($file) > 0){ 
    if(is_file($file)){ 
        $message .= "--{$mime_boundary}\n"; 
        $fp =    @fopen($file,"rb"); 
        $data =  @fread($fp,filesize($file)); 
 
        @fclose($fp); 
        $data = chunk_split(base64_encode($data)); 
        $message .= "Content-Type: application/octet-stream; name=\"".basename($file)."\"\n" .  
        "Content-Description: ".basename($file)."\n" . 
        "Content-Disposition: attachment;\n" . " filename=\"".basename($file)."\"; size=".filesize($file).";\n" .  
        "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n"; 
    } 
} 
$message .= "--{$mime_boundary}--"; 
$returnpath = "-f" . $from; 
 
// Send email 
$mail = @mail($to, $subject, $message, $headers, $returnpath);  
 
// Email sending status 
echo $mail?"<h1>Email Sent Successfully!</h1>":"<h1>Email sending failed.</h1>"; 
}


 
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Feedback Form</title>
    
   <!--  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    --> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     
    <style type="text/css">

    	div.stars {
  width: max-content
}

input.star {
  display: none
}

label.star {
  padding: 0 5px;
  font-size: 25px;
  color: #444;
  float: right;
  transition: all .2s
}

input.star:checked~label.star:before {
  content: '\f005';
  color: #FD4;
  transition: all .25s
}

input.star-5:checked~label.star:before {
  color: #FE7;
  text-shadow: 0 0 20px #952
}

input.star-1:checked~label.star:before {
  color: #F62
}

label.star:hover {
  transform: rotate(-15deg) scale(1.3)
}

label.star:before {
  content: '\f006';
  font-family: FontAwesome
}

@import url(https://fonts.googleapis.com/css?family=Roboto:300);

.login-page {
  width: 360px;
  padding: 8% 0 0;
  margin: auto;
}
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #4CAF50;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
}
.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #4CAF50;
  text-decoration: none;
}
.form .register-form {
  display: none;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
  clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}
label {

  margin-top:10px;
}
</style>
</head>
<body>
	<div class="login-page">
  <div class="form">
    <p>Feedback Form</p>
    <form class="login-form" action="" method="post">
      <input type="text" name="name" placeholder="enter your name"/>
      <input type="email" name="email" placeholder="enter your email"/>
      <input type="text"  name="mobile" placeholder="enter your mobile number" >
      
      
      <div class="stars " >
        
      	<input class="one_hr star star-1" id="one_hr-1" value="5" type="radio" name="one_hr"/>
                              <label class="star star-1" for="one_hr-1"></label> 
                              <input class="one_hr star star-2" id="one_hr-2" value="4" type="radio" name="one_hr"/>
                              <label class="star star-2" for="one_hr-2"></label>
                              <input class="one_hr star star-3" id="one_hr-3" value="3" type="radio" name="one_hr"/>
                              <label class="star star-3" for="one_hr-3"></label>
                              <input class="one_hr star star-4" id="one_hr-4" value="2" type="radio" name="one_hr"/>
                              <label class="star star-4" for="one_hr-4"></label>
                              <input class="one_hr star star-5" id="one_hr-5" value="1" type="radio" name="one_hr"/>
                              <label class="star star-5" for="one_hr-5"></label>

      </div>
      <button type="submit" name="submit" class="mt-2" style=" margin-top: 5%">Submit</button>
      
    </form>
  </div>
</div>
	
	                       <script type="text/javascript">
                           	$('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});
                           </script>
</body>
</html>